package edu.jonathangf.filmlist.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import edu.jonathangf.filmlist.R
import edu.jonathangf.filmlist.databinding.ItemListBinding
import edu.jonathangf.filmlist.model.Film

/**
 * La clase FilmAdapter
 */
class FilmAdapter(
    val films: MutableList<Film>,
    private val onItemLongClick: (Film, Int) -> Unit
) : RecyclerView.Adapter<FilmAdapter.FilmViewHolder>() {

    /**
     * Crea un nuevo ViewHolder para un elemento del RecyclerView.
     *
     * @param parent El ViewGroup padre del ViewHolder.
     * @param viewType El tipo de vista del ViewHolder.
     * @return El nuevo ViewHolder.
     */
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FilmViewHolder {
        return FilmViewHolder(
            ItemListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ).root
        )
    }

    /**
     * Vincula los datos de un objeto `Film` a un ViewHolder.
     *
     * @param holder El ViewHolder al que se vincularán los datos.
     * @param position La posición del elemento en la lista.
     */
    override fun onBindViewHolder(holder: FilmAdapter.FilmViewHolder, position: Int) {
        holder.bind(films[position])
    }
    /**
     * Devuelve el número de elementos en la lista.
     *
     * @return El número de elementos en la lista.
     */
    override fun getItemCount(): Int = films.size

    /**
     * Clase interna que representa un ViewHolder para un elemento del RecyclerView.
     *
     * @param view La vista del ViewHolder.
     */
    inner class FilmViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private val bindingFilm = ItemListBinding.bind(view)
        /**
         * Vincula los datos de un objeto `Film` a la vista del ViewHolder.
         *
         * @param film El objeto `Film` que se vinculará a la vista.
         */
        fun bind(film: Film) {
            bindingFilm.tvTitle.text = film.title
            bindingFilm.tvDirector.text = film.director

            Glide.with(itemView)
                .load(film.cover)
                .centerCrop()
                .transform(RoundedCorners(16))
                .into(bindingFilm.ivCover)
            itemView.setOnLongClickListener {
                onItemLongClick(film, adapterPosition)
                true
            }
            bindingFilm.tvYear.text = film.year.toString()
            bindingFilm.tvDuration.text =
                itemView.context.getString(R.string.txt_duration, film.duration.toString())
            bindingFilm.tvGenre.text = film.genre
        }
    }
}