package edu.jonathangf.filmlist

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
import edu.jonathangf.filmlist.adapters.FilmAdapter
import edu.jonathangf.filmlist.databinding.ActivityMainBinding
import edu.jonathangf.filmlist.model.Film

/**
 * Programa que muestra una lista de objetos cargados desde un archivo csv mediante la clase Utils,
 * al borrar un objeto muestra un mensaje y se pueden recuperar en ese mismo momento pulsando el
 * UNDO que se muestra en el snackbar. Al borrar todas los objetos se muestra un mensaje.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var films: MutableList<Film> = arrayListOf()
    private lateinit var filmsAdapter: FilmAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        films = Film.getFilms(this)

        filmsAdapter = FilmAdapter(films, onItemLongClick =

        { film, position ->
            val removedItem = filmsAdapter.films.removeAt(position)
            if (removedItem != null) {
                filmsAdapter.notifyItemRemoved(position)

                val snackbar = Snackbar.make(
                    binding.root, getString(R.string.txt_film_deleted, film.title),
                    Snackbar.LENGTH_LONG

                )
                snackbar.setAction(R.string.txt_undo) {
                    filmsAdapter.films.add(position, removedItem)
                    filmsAdapter.notifyItemInserted(position)

                    binding.tvWarning.visibility = View.GONE
                }
                //Ajusto la altura de la snackbar
                val params = CoordinatorLayout.LayoutParams(snackbar.view.layoutParams)
                params.gravity = Gravity.BOTTOM
                params.setMargins(0, 0, 0, -binding.root.paddingBottom)
                snackbar.view.layoutParams = params
                snackbar.show()
                //Muestro un mensaje cuando la lista esta vacia
                if (filmsAdapter.films.isEmpty()) {
                    binding.tvWarning.text = getString(R.string.warning_no_films)
                    binding.tvWarning.visibility = View.VISIBLE
                }
            }
        }
        )
        binding.mRecycler.adapter = filmsAdapter
    }
}


