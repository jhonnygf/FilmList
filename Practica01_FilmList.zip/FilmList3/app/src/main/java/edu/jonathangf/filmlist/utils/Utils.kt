package edu.jonathangf.filmlist.utils

import android.content.Context
import android.util.Log
import edu.jonathangf.filmlist.R
import edu.jonathangf.filmlist.model.Film
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/**
 * Lee un archivo raw (en formato de texto) desde los recursos de la aplicación y lo convierte en
 * una lista de objetos `Film`.
 *
 * El archivo raw debe estar en formato CSV (valores separados por comas), donde cada línea
 * representa un film y los valores están separados por ';'.
 *
 * El orden de los valores en cada línea debe coincidir con las
 * propiedades del objeto `Film`.
 *
 * @param context El contexto de la aplicación.
 * @return Una lista de objetos `Film` leídos del archivo raw.
 *
 * @throws IOException Si ocurre un error al leer el archivo.
 */
class Utils {

    fun readRawFile(context: Context): MutableList<Film> {
        val films = mutableListOf<Film>()

        try {
            val entrada = InputStreamReader(
                context.resources.openRawResource(R.raw.films)
            )
            val br = BufferedReader(entrada)
            var linea = br.readLine()
            while (!linea.isNullOrEmpty()) {
                val parts = linea.split(";")
                val film = Film(
                    id = parts[0].toInt(),
                    title = parts[1],
                    year = parts[2].toInt(),
                    duration = parts[3].toInt(),
                    genre = parts[4],
                    director = parts[5],
                    cover = parts[6]
                )
                films.add(film)
                linea = br.readLine()
            }
            br.close()
            entrada.close()

        } catch (e: IOException) {
            Log.e("Error al leer el archivo:" ,e.message.toString())
        }
        return films
    }
}