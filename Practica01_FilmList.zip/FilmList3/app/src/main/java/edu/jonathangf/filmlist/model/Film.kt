package edu.jonathangf.filmlist.model

import android.content.Context
import android.os.Parcelable
import edu.jonathangf.filmlist.utils.Utils
import kotlinx.parcelize.Parcelize

/**
 * La clase Film es una clase de datos que representa una película.
 * Es serializable gracias a la anotación @Parcelize y tiene un objeto compañero
 * que proporciona un método para leer la lista de películas desde un archivo CSV.
 */

@Parcelize
data class Film(
    val id : Int,
    val title : String,
    val year : Int,
    val duration : Int,
    val genre : String,
    val director : String,
    val cover : String
):Parcelable {
    companion object {
        fun getFilms(context: Context): MutableList<Film> {
            val utils = Utils()
            return utils.readRawFile(context)
        }
    }
}
